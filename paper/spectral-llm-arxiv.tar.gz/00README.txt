arXiv Submission Package
========================

Main file: draft.tex

Compile with:
  pdflatex draft.tex

Figures: All PDF figures are in the figures/ subdirectory.

Bibliography: Embedded in draft.tex (no .bbl file needed).

Package requirements: Standard LaTeX packages only (geometry, amsmath, graphicx, etc.)

GitHub repository: https://github.com/gogipav14/spectral-llm
